// To parse this JSON data, do
//
//     final luckyDrawModel = luckyDrawModelFromMap(jsonString);

import 'dart:convert';

class LuckyDrawModel {
  LuckyDrawModel({
    this.result1,
    this.result2,
  });

  List<Result1> result1;
  Result2 result2;

  factory LuckyDrawModel.fromJson(String str) =>
      LuckyDrawModel.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory LuckyDrawModel.fromMap(Map<String, dynamic> json) => LuckyDrawModel(
        result1:
            List<Result1>.from(json["result1"].map((x) => Result1.fromMap(x))),
        result2: Result2.fromMap(json["result2"]),
      );

  Map<String, dynamic> toMap() => {
        "result1": List<dynamic>.from(result1.map((x) => x.toMap())),
        "result2": result2.toMap(),
      };
}

class Result1 {
  Result1({
    this.id,
    this.userMobile,
    this.ticketNo,
    this.assignedDate,
    this.title,
    this.description,
    this.logoUrl,
    this.status,
  });

  String id;
  String userMobile;
  String ticketNo;
  String assignedDate;
  String title;
  String description;
  String logoUrl;
  String status;

  factory Result1.fromJson(String str) => Result1.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory Result1.fromMap(Map<String, dynamic> json) => Result1(
        id: json["ID"],
        userMobile: json["UserMobile"],
        ticketNo: json["TicketNo"],
        assignedDate: json["Assigned_Date"],
        title: json["Title"],
        description: json["Description"],
        logoUrl: json["LogoUrl"],
        status: json["Status"],
      );

  Map<String, dynamic> toMap() => {
        "ID": id,
        "UserMobile": userMobile,
        "TicketNo": ticketNo,
        "Assigned_Date": assignedDate,
        "Title": title,
        "Description": description,
        "LogoUrl": logoUrl,
        "Status": status,
      };
}

class Result2 {
  Result2({
    this.ticketCount,
    this.wonTicketCount,
    this.description,
  });

  String ticketCount;
  String wonTicketCount;
  String description;

  factory Result2.fromJson(String str) => Result2.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory Result2.fromMap(Map<String, dynamic> json) => Result2(
        ticketCount: json["TicketCount"],
        wonTicketCount: json["WonTicketCount"],
        description: json["Description"],
      );

  Map<String, dynamic> toMap() => {
        "TicketCount": ticketCount,
        "WonTicketCount": wonTicketCount,
        "Description": description,
      };
}
