// ignore: camel_case_types
class datapassingModel {
  final String mobileNumber;
  final String otp;

  datapassingModel(this.mobileNumber, this.otp);
}
