class Paymentkeys {
  //static String baseUrls = "https://admindemo.matsapp.in/";
  // static String baseUrls = "https://capi.matsapp.in/";
  //static String baseUrls = "https://capidemo.matsapp.in/";
  static String razerPayKey = "rzp_live_1BNS14HsCEFiG7";
}
