class AppConstants {
  static const String AppName = "Mats App";

  static const String StoreInfo =
      ". All Offers displayed in the application are completely managed by the store owner";

  
}
