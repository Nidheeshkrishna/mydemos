import 'package:flutter/widgets.dart';

class AppImages {
  AppImages._();

  static const ImageProvider successImage =
      AssetImage('assets/images/success_image.png');
}
